package contact;

import java.util.LinkedHashMap;
import java.util.Map;
public class Contact {
	 private Long id;
    private String nom;
    private String prenom;
    private String telephone;
    private String email;
    private String adresse;
    private String dateNaissance;
    private String notes;
    
    
    public Contact(String nom, String prenom, String telephone, String email, String adresse,
    		String dateNaissance, String notes) {     
        this.nom = nom;
        this.prenom = prenom;
        this.telephone = telephone;
        this.email = email;
        this.adresse = adresse;
        this.dateNaissance = dateNaissance != null && !dateNaissance.isEmpty() ? dateNaissance : "01/01/2000";
        this.notes = notes;
        
    }
    
    // Getters et Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }
    
    public String getPrenom() { return prenom; }
    public void setPrenom(String prenom) { this.prenom = prenom; }
    
    public String getTelephone() { return telephone; }
    public void setTelephone(String telephone) { this.telephone = telephone; }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getAdresse() { return adresse; }
    public void setAdresse(String adresse) {this.adresse = adresse; }
    public String getDateNaissance() { return dateNaissance; }
    public void setDateNaissance(String dateNaissance) {this.dateNaissance = dateNaissance; }
    public String getNotes() { return notes; }
    public void setNotes(String notes) {this.notes = notes; }
    
    
    
}
