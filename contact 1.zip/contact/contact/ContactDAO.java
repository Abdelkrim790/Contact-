package contact;


import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ContactDAO {
    private static final String URL = "jdbc:mysql://localhost:3306/gestion_contacts";
    private static final String USER = "root"; // remplacez par votre utilisateur
    private static final String PASSWORD = ""; // remplacez par votre mot de passe
    
    private Connection getConnection() throws SQLException {
        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            System.err.println("Erreur de connexion à la base de données:");
            System.err.println("URL: " + URL);
            System.err.println("Utilisateur: " + USER);
            e.printStackTrace();
            throw e;
        }
    }
    
    // ajouter un contact
    public void ajouterContact(Contact contact) throws SQLException { //definition de la requête SQL avec des paramètres (?)
        String sql = "INSERT INTO contacts (nom, prenom, telephone, email, adresse, date_naissance, notes) " +
                     "VALUES (?, ?, ?, ?, ?, STR_TO_DATE(?, '%d/%m/%Y'), ?)";
        
        try (Connection conn = getConnection(); //obtention d'une connexion et création d'un preparedstatement
             PreparedStatement stmt = conn.prepareStatement(sql)) {
        	
            //remplissage des paramètres de la requête
            stmt.setString(1, contact.getNom());
            stmt.setString(2, contact.getPrenom());
            stmt.setString(3, contact.getTelephone());
            stmt.setString(4, contact.getEmail());
            stmt.setString(5, contact.getAdresse());
            stmt.setString(6, contact.getDateNaissance()); // Format attendu : "JJ/MM/AAAA"
            stmt.setString(7, contact.getNotes());
            
            stmt.executeUpdate();
            //fermeture automatique des ressources
        }
    }
    
    // récupérer tous les contacts
    public List<Contact> getTousContacts() throws SQLException { //création d'une liste vide pour stocker les résultats
        List<Contact> contacts = new ArrayList<>();
        String sql = "SELECT * FROM contacts ORDER BY nom, prenom"; //définition de la requête SQL
        
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Contact contact = new Contact(  //création d'un objet Contact pour chaque enregistrement
                    rs.getString("nom"),
                    rs.getString("prenom"),
                    rs.getString("telephone"),
                    rs.getString("email"),
                    rs.getString("adresse"),
                    rs.getString("date_naissance"),
                    rs.getString("notes")
                );
                contacts.add(contact); //ajout du contact à la liste
            }
        }
        return contacts; //retour de la liste complète
    }
    
    // modifier un contact
    public void modifierContact(Contact ancienContact, Contact nouveauContact) throws SQLException {
    	// définition de la requête SQL de mise à jour
        String sql = "UPDATE contacts SET nom=?, prenom=?, telephone=?, email=?, " +
                     "adresse=?, date_naissance=?, notes=? " +
                     "WHERE nom=? AND prenom=? AND telephone=?";
        
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            // paramétrage des NOUVELLES valeurs à mettre à jour
            stmt.setString(1, nouveauContact.getNom());
            stmt.setString(2, nouveauContact.getPrenom());
            stmt.setString(3, nouveauContact.getTelephone());
            stmt.setString(4, nouveauContact.getEmail());
            stmt.setString(5, nouveauContact.getAdresse());
            stmt.setString(6, nouveauContact.getDateNaissance());
            stmt.setString(7, nouveauContact.getNotes());
            
            // anciennes valeurs pour identification
            stmt.setString(8, ancienContact.getNom());
            stmt.setString(9, ancienContact.getPrenom());
            stmt.setString(10, ancienContact.getTelephone());
            
            // exécution de la mise à jour
            int rowsAffected = stmt.executeUpdate();
            
            // vérification qu'une ligne a bien été modifiée
            if (rowsAffected == 0) {
                throw new SQLException("Échec de la mise à jour, contact non trouvé");
            }
        }
    }
    
    // supprimer un contact
    public void supprimerContact(Contact contact) throws SQLException {
    	//requête SQL pour supprimer un contact
        String sql = "DELETE FROM contacts WHERE nom=? AND prenom=? AND telephone=?";
        
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, contact.getNom());
            stmt.setString(2, contact.getPrenom());
            stmt.setString(3, contact.getTelephone());
            
            //exécution de la suppression
            int rowsAffected = stmt.executeUpdate();
            
            //vérification qu'une ligne a bien été supprimée
            if (rowsAffected == 0) {
                throw new SQLException("Aucun contact trouvé pour suppression");
            }
        }
    }
    
    // rechercher des contacts
    public List<Contact> rechercherContacts(String terme) throws SQLException {
    	//création d'une liste vide pour stocker les résultats
        List<Contact> contacts = new ArrayList<>();
        //requête SQL avec LIKE pour une recherche partielle
        String sql = "SELECT * FROM contacts WHERE nom LIKE ? OR prenom LIKE ? OR telephone LIKE ? " +
                    "ORDER BY nom, prenom";
        
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
        	//formatage du terme de recherche (ajout des % pour LIKE)
            
            String searchTerm = "%" + terme + "%";
            // assignation des paramètres
            stmt.setString(1, searchTerm);
            stmt.setString(2, searchTerm);
            stmt.setString(3, searchTerm);
            //parcours de tous les résultats
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                	//création d'un objet Contact pour chaque résultat
                    Contact contact = new Contact(
                        rs.getString("nom"),
                        rs.getString("prenom"),
                        rs.getString("telephone"),
                        rs.getString("email"),
                        rs.getString("adresse"),
                        rs.getString("date_naissance"),
                        rs.getString("notes")
                    );
                    //ajout du contact à la liste des résultats
                    contacts.add(contact);
                }
            }
        }
        return contacts;
    }
}