package contact;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;

public class GestionContacts {
    private ContactDAO contactDAO;
    
    public GestionContacts() {
        try {
            // Charger le driver MySQL
            Class.forName("com.mysql.jdbc.Driver");
            contactDAO = new ContactDAO();
        } catch (ClassNotFoundException e) {
            showError("Erreur de configuration", "Impossible de charger le driver JDBC");
        }
    }
    
    // Ajouter un contact
    public boolean ajouterContact(Contact contact) {
        try {
            contactDAO.ajouterContact(contact);
            return true;
        } catch (SQLException e) {
            showError("Erreur d'ajout", "Impossible d'ajouter le contact: " + e.getMessage());
            return false;
        }
    }
    
    // Récupérer tous les contacts
    public List<Contact> getTousContacts() {
        try {
            return contactDAO.getTousContacts();
        } catch (SQLException e) {
            showError("Erreur de lecture", "Impossible de charger les contacts: " + e.getMessage());
            return null;
        }
    }
    
    // Modifier un contact
    public boolean modifierContact(Contact ancienContact, Contact nouveauContact) {
        try {
            contactDAO.modifierContact(ancienContact, nouveauContact);
            return true;
        } catch (SQLException e) {
            showError("Erreur de modification", "Impossible de modifier le contact: " + e.getMessage());
            return false;
        }
    }
    
    // Supprimer un contact
    public boolean supprimerContact(Contact contact) {
        try {
            contactDAO.supprimerContact(contact);
            return true;
        } catch (SQLException e) {
            showError("Erreur de suppression", "Impossible de supprimer le contact: " + e.getMessage());
            return false;
        }
    }
    
    // Rechercher des contacts
    public List<Contact> rechercherContacts(String terme) {
        try {
            return contactDAO.rechercherContacts(terme);
        } catch (SQLException e) {
            showError("Erreur de recherche", "Impossible d'effectuer la recherche: " + e.getMessage());
            return null;
        }
    }
    
    // Obtenir un contact par son ID
    public Contact getContactParId(long id) {
        try {
            List<Contact> contacts = contactDAO.getTousContacts();
            for (Contact contact : contacts) {
                if (contact.getId() != null && contact.getId() == id) {
                    return contact;
                }
            }
            return null;
        } catch (SQLException e) {
            showError("Erreur de lecture", "Impossible de trouver le contact: " + e.getMessage());
            return null;
        }
    }
    
    // Méthode utilitaire pour afficher les erreurs
    private void showError(String titre, String message) {
        JOptionPane.showMessageDialog(null, message, titre, JOptionPane.ERROR_MESSAGE);
    }
}

