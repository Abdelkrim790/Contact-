package contact;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class ContactDialog extends JDialog {
    private Contact contact;
    private boolean confirmed = false;

    // Composants du formulaire
    private JTextField nomField, prenomField, telephoneField, emailField, adresseField;
    private JFormattedTextField dateNaissanceField;
    private JTextArea notesArea;
    private JButton okButton;

    public ContactDialog(JFrame parent, Contact contact) {
        super(parent, contact == null ? "Nouveau Contact" : "Modifier Contact", true);
        this.contact = contact != null ? contact : new Contact("", "", "", "", "", "", "");
        
        initUI();
        pack();
        setLocationRelativeTo(parent);
    }

    private void initUI() {
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Formulaire
        JPanel formPanel = new JPanel(new GridLayout(0, 2, 5, 5));
        
        nomField = addFormField(formPanel, "Nom:", contact.getNom());
        prenomField = addFormField(formPanel, "Prénom:", contact.getPrenom());
        telephoneField = addFormField(formPanel, "Téléphone:", contact.getTelephone());
        emailField = addFormField(formPanel, "Email:", contact.getEmail());
        adresseField = addFormField(formPanel, "Adresse:", contact.getAdresse());
        
        // Champ de date avec formatteur
        dateNaissanceField = new JFormattedTextField();
        dateNaissanceField.setValue(contact.getDateNaissance());
        formPanel.add(new JLabel("Date de naissance (JJ/MM/AAAA):"));
        formPanel.add(dateNaissanceField);
        
        notesArea = new JTextArea(contact.getNotes(), 5, 20);
        formPanel.add(new JLabel("Notes:"));
        formPanel.add(new JScrollPane(notesArea));

        mainPanel.add(formPanel, BorderLayout.CENTER);

        // Boutons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        okButton = new JButton("OK");
        JButton cancelButton = new JButton("Annuler");

        okButton.addActionListener(this::handleOkAction);
        cancelButton.addActionListener(e -> dispose());

        buttonPanel.add(okButton);
        buttonPanel.add(cancelButton);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    private JTextField addFormField(JPanel panel, String label, String value) {
        panel.add(new JLabel(label));
        JTextField field = new JTextField(value);
        panel.add(field);
        return field;
    }

    private void handleOkAction(ActionEvent e) {
        if (!validerDateNaissance()) {
            return;
        }
        confirmed = true;
        updateContact();
        dispose();
    }

    private boolean validerDateNaissance() {
        String dateText = dateNaissanceField.getText().trim();
        
        if (dateText.isEmpty()) {
            return true; // Accepte les dates vides
        }
        
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            sdf.setLenient(false);
            sdf.parse(dateText);
            return true;
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(this, 
                "Format de date invalide. Utilisez JJ/MM/AAAA", 
                "Erreur de format", 
                JOptionPane.ERROR_MESSAGE);
            dateNaissanceField.requestFocus();
            return false;
        }
    }

    private void updateContact() {
        contact.setNom(nomField.getText());
        contact.setPrenom(prenomField.getText());
        contact.setTelephone(telephoneField.getText());
        contact.setEmail(emailField.getText());
        contact.setAdresse(adresseField.getText());
        contact.setDateNaissance(dateNaissanceField.getText());
        contact.setNotes(notesArea.getText());
    }

    public boolean showDialog() {
        setVisible(true);
        return confirmed;
    }

    public Contact getContact() {
        return contact;
    }
}