package contact;


import javax.swing.*;
import java.awt.*;

public class ContactProfileDialog extends JDialog {
    public ContactProfileDialog(JFrame parent, Contact contact) {
        super(parent, "Profil de " + contact.getPrenom() + " " + contact.getNom(), true);
        setSize(500, 400);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout(10, 10));
        
        // Panel principal avec padding
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        // En-tête avec photo (placeholder)
        JPanel headerPanel = new JPanel(new BorderLayout());
        JLabel nameLabel = new JLabel(contact.getPrenom() + " " + contact.getNom());
        nameLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        headerPanel.add(nameLabel, BorderLayout.WEST);
        
        // Photo placeholder
        JLabel photoLabel = new JLabel(new ImageIcon("profile_placeholder.png"));
        photoLabel.setPreferredSize(new Dimension(80, 80));
        headerPanel.add(photoLabel, BorderLayout.EAST);
        
        // Détails du contact
        JPanel detailsPanel = new JPanel();
        detailsPanel.setLayout(new BoxLayout(detailsPanel, BoxLayout.Y_AXIS));
        detailsPanel.setBorder(BorderFactory.createTitledBorder("Informations"));
        
        addDetailRow(detailsPanel, "📞 Téléphone:", contact.getTelephone());
        addDetailRow(detailsPanel, "✉️ Email:", contact.getEmail());
        addDetailRow(detailsPanel, "🏠 Adresse:", contact.getAdresse());
        addDetailRow(detailsPanel, "🎂 Date de naissance:", contact.getDateNaissance());
        
        // Notes
        JTextArea notesArea = new JTextArea(contact.getNotes());
        notesArea.setEditable(false);
        notesArea.setLineWrap(true);
        notesArea.setWrapStyleWord(true);
        notesArea.setBorder(BorderFactory.createTitledBorder("📝 Notes"));
        
        // Boutons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton closeButton = new JButton("Fermer");
        closeButton.addActionListener(e -> dispose());
        
        buttonPanel.add(closeButton);
        
        // Assemblage
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(detailsPanel, BorderLayout.CENTER);
        mainPanel.add(new JScrollPane(notesArea), BorderLayout.SOUTH);
        
        add(mainPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    private void addDetailRow(JPanel panel, String label, String value) {
        JPanel rowPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        rowPanel.add(new JLabel(label));
        rowPanel.add(new JLabel(value));
        panel.add(rowPanel);
    }
    
}