package contact;


import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class ApplicationContacts extends JFrame {
    private GestionContacts gestionContacts;
    private DefaultListModel<Contact> listModel;
    private JList<Contact> contactsList;
    private JTextField searchField;
    private JButton searchButton;

    public ApplicationContacts() {
        initComponents();
        setupUI();
        setupEventHandlers();
        loadContacts();
    }

    private void initComponents() {
        gestionContacts = new GestionContacts();
        listModel = new DefaultListModel<>();
        contactsList = new JList<>(listModel);
        searchField = new JTextField(20);
        searchButton = new JButton("Rechercher");
    }

    private void setupUI() {
        setTitle("📞 Gestionnaire de Contacts");
        setSize(900, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Configuration du layout principal
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(15, 15, 15, 15));
        mainPanel.setBackground(new Color(245, 245, 245));

        // Ajout des composants
        mainPanel.add(createHeaderPanel(), BorderLayout.NORTH);
        mainPanel.add(createListPanel(), BorderLayout.CENTER);
        mainPanel.add(createButtonPanel(), BorderLayout.SOUTH);

        add(mainPanel);
    }

    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(new Color(70, 130, 180));
        panel.setBorder(new EmptyBorder(10, 15, 10, 15));

        JLabel titleLabel = new JLabel("Gestionnaire de Contacts");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(Color.BLACK);

        JPanel searchPanel = new JPanel(new BorderLayout(10, 10));
        searchField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        searchButton.setBackground(new Color(100, 149, 237));
        searchButton.setForeground(Color.BLACK);
        searchButton.setFont(new Font("Segoe UI", Font.BOLD, 12));

        searchPanel.add(searchField, BorderLayout.CENTER);
        searchPanel.add(searchButton, BorderLayout.EAST);
        panel.add(titleLabel, BorderLayout.WEST);
        panel.add(searchPanel, BorderLayout.EAST);

        return panel;
    }

    private JPanel createListPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));

        contactsList.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        contactsList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        contactsList.setCellRenderer(new ContactListRenderer());

        JScrollPane scrollPane = new JScrollPane(contactsList);
        scrollPane.setBorder(null);
        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createButtonPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
        panel.setBackground(new Color(240, 240, 240));

        Color buttonColor = new Color(70, 130, 180);
        Font buttonFont = new Font("Segoe UI", Font.BOLD, 14);

        panel.add(createStyledButton("➕ Ajouter", buttonColor, buttonFont, e -> addContact()));
        panel.add(createStyledButton("✏️ Modifier", buttonColor, buttonFont, e -> editContact()));
        panel.add(createStyledButton("🗑️ Supprimer", buttonColor, buttonFont, e -> deleteContact()));

        return panel;
    }

    private JButton createStyledButton(String text, Color bgColor, Font font, ActionListener listener) {
        JButton button = new JButton(text);
        button.setBackground(bgColor);
        button.setForeground(Color.BLACK);
        button.setFont(font);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(8, 20, 8, 20));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.addActionListener(listener);

        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(bgColor.darker());
            }
            public void mouseExited(MouseEvent e) {
                button.setBackground(bgColor);
            }
        });

        return button;
    }

    private void setupEventHandlers() {
        // Double-clic pour modifier
        contactsList.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    editContact();
                }
            }
        });

        // Recherche par bouton ou Entrée
        searchButton.addActionListener(e -> searchContacts());
        searchField.addActionListener(e -> searchContacts());
    }

    private void loadContacts() {
        try {
            listModel.clear();
            List<Contact> contacts = gestionContacts.getTousContacts();
            if (contacts != null) {
                contacts.forEach(listModel::addElement);
            } else {
                showError("Erreur de chargement", "Aucun contact trouvé ou erreur de connexion");
            }
        } catch (Exception e) {
            showError("Erreur de chargement", "Impossible de charger les contacts: " + e.getMessage());
        }
    }

    private void addContact() {
        ContactDialog dialog = new ContactDialog(this, null);
        if (dialog.showDialog()) {
            try {
                gestionContacts.ajouterContact(dialog.getContact());
                loadContacts();
                showSuccess("Contact ajouté avec succès");
            } catch (Exception e) {
                showError("Erreur d'ajout", "Impossible d'ajouter le contact: " + e.getMessage());
            }
        }
    }

    private void editContact() {
        Contact selected = contactsList.getSelectedValue();
        if (selected != null) {
            // Crée une copie du contact sélectionné pour l'ancien contact
            Contact ancienContact = new Contact(
                selected.getNom(),
                selected.getPrenom(),
                selected.getTelephone(),
                selected.getEmail(),
                selected.getAdresse(),
                selected.getDateNaissance(),
                selected.getNotes()
            );
            
            ContactDialog dialog = new ContactDialog(this, selected);
            if (dialog.showDialog()) {
                gestionContacts.modifierContact(ancienContact, dialog.getContact());
            }
        } else {
            showWarning("Aucun contact sélectionné", "Veuillez sélectionner un contact à modifier");
        }
    }

    private void deleteContact() {
        Contact selected = contactsList.getSelectedValue();
        if (selected != null) {
            int confirm = JOptionPane.showConfirmDialog(
                this,
                "Êtes-vous sûr de vouloir supprimer " + selected.getNom() + " " + selected.getPrenom() + " ?",
                "Confirmation de suppression",
                JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    gestionContacts.supprimerContact(selected);
                    loadContacts();
                    showSuccess("Contact supprimé avec succès");
                } catch (Exception e) {
                    showError("Erreur de suppression", "Impossible de supprimer le contact: " + e.getMessage());
                }
            }
        } else {
            showWarning("Aucun contact sélectionné", "Veuillez sélectionner un contact à supprimer");
        }
    }

    private void searchContacts() {
        String searchTerm = searchField.getText().trim();
        if (!searchTerm.isEmpty()) {
            try {
                listModel.clear();
                List<Contact> results = gestionContacts.rechercherContacts(searchTerm);
                results.forEach(listModel::addElement);
            } catch (Exception e) {
                showError("Erreur de recherche", "Impossible d'effectuer la recherche: " + e.getMessage());
            }
        } else {
            loadContacts();
        }
    }

    // Méthodes utilitaires pour les messages
    private void showError(String title, String message) {
        JOptionPane.showMessageDialog(this, message, title, JOptionPane.ERROR_MESSAGE);
    }

    private void showWarning(String title, String message) {
        JOptionPane.showMessageDialog(this, message, title, JOptionPane.WARNING_MESSAGE);
    }

    private void showSuccess(String message) {
        JOptionPane.showMessageDialog(this, message, "Succès", JOptionPane.INFORMATION_MESSAGE);
    }

    // Renderer personnalisé pour la liste
    private static class ContactListRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                    boolean isSelected, boolean cellHasFocus) {
            super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            
            if (value instanceof Contact) {
                Contact contact = (Contact) value;
                setText(String.format("<html><b>%s %s</b><br><font color='gray'>%s | %s</font></html>",
                    contact.getNom(),
                    contact.getPrenom(),
                    contact.getTelephone(),
                    contact.getEmail()));
                
                if (isSelected) {
                    setBackground(new Color(220, 240, 255));
                    setForeground(Color.BLACK);
                }
            }
            return this;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                new ApplicationContacts().setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}

